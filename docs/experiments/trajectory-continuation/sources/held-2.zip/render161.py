"""Standalone report/replay and saved-state scientific figures."""
from analyze161 import R,D,OLD,read,save
import base64,json,math,statistics
def n(x,d=3):return '—' if x is None else f'{x:.{d}f}'
def table(head,rows):return '\n'.join(['|'+'|'.join(head)+'|','|'+'|'.join(['---']*len(head))+'|']+['|'+'|'.join(str(x) for x in r)+'|' for r in rows])+'\n'
def plots(a):
 import matplotlib;matplotlib.use('Agg')
 import matplotlib.pyplot as plt
 plt.rcParams.update({'font.size':10,'axes.grid':True,'grid.alpha':.2});out=D/'plots';out.mkdir(exist_ok=True);hist=read(D/'historical-forensics.json.gz');old=hist['last20s']
 fig,axs=plt.subplots(5,1,figsize=(12,12),sharex=True)
 t=[q['t'] for q in old];axs[0].plot(t,[q['offset'] for q in old],label='160 actual offset');axs[1].plot(t,[q['lateral_velocity'] for q in old],label='160 lateral velocity');axs[2].plot(t,[math.degrees(q['beta']) for q in old],label='160 beta');axs[2].plot(t,[q['yaw'] for q in old],label='160 yaw rad/s');axs[3].plot(t,[q['requested_gas'] for q in old],label='160 requested gas',alpha=.7);axs[3].plot(t,[q['gas'] for q in old],label='160 active gas',alpha=.7);axs[4].plot(t,[q['pose'] for q in old],label='160 pose');axs[4].plot(t,[q['swept'] for q in old],label='160 swept')
 if a['native']:
  raw=read(R/a['native'][0]['source'])['Riders'][0]['Samples'];raw=[s for s in raw if 47<=s['Input']['Time']<=67];tt=[s['Input']['Time'] for s in raw]
  axs[0].plot(tt,[s['Input']['Rider']['Road']['OffsetMeters'] for s in raw],label='161 actual offset');axs[1].plot(tt,[sum(s['Input']['Rider']['Velocity'][k]*s['Input']['Rider']['Road']['Outward'][k] for k in ['X','Y']) for s in raw],label='161 lateral velocity');axs[2].plot(tt,[math.degrees(s['Input']['Rider']['SlideRadians']) for s in raw],label='161 beta');axs[3].plot(tt,[s['Input']['Active']['Drive'] for s in raw],label='161 active gas');axs[4].plot(tt,[s['Certificate'] for s in raw],label='161 swept')
 for ax,y in zip(axs,['offset [m]','outward velocity [m/s]','deg / rad/s','gas [0–1]','clearance [m]']):ax.set_ylabel(y);ax.legend(fontsize=8,ncol=3)
 axs[4].axhline(.5,color='red',ls='--');axs[-1].set_xlabel('actual native time [s]; original160 stops at67');fig.tight_layout();fig.savefig(out/'last20-native.png',dpi=150);plt.close(fig)
 tail=hist['v6_saved_tail'];fig,axs=plt.subplots(3,1,figsize=(12,8),sharex=True);tt=[q['time'] for q in tail];axs[0].plot(tt,[q['speed']*3.6 for q in tail],label='160 v6 diagnostic actual speed');axs[0].plot(tt,[q['target_speed']*3.6 if q['target_speed'] is not None else None for q in tail],label='160 v6 proposal target');axs[1].plot(tt,[q['action']['Drive'] for q in tail],label='160 v6 requested gas');axs[2].plot(tt,[math.degrees(q['beta']) for q in tail],label='160 v6 beta')
 recovered=next((q for q in a['diagnostics'] if q['InitialTime']==67),None)
 if recovered:
  q=read(R/recovered['source'])['Selected'];p=q['Points'];tt=[x['Time'] for x in p];axs[0].plot(tt,[x['Rider']['Speed']*3.6 for x in p],label='161 recovered forecast speed');axs[1].plot([s['Input']['Time'] for s in q['States'][:-1]],[x['Drive'] for x in q['Actions']],label='161 requested gas');axs[2].plot(tt,[math.degrees(x['Rider']['SlideRadians']) for x in p],label='161 beta')
 for ax,label in zip(axs,['km/h','gas','beta [deg]']):ax.set_ylabel(label);ax.legend(fontsize=8)
 axs[-1].set_xlabel('forecast time [s]; these are not native samples after67');fig.tight_layout();fig.savefig(out/'terminal-cause.png',dpi=150);plt.close(fig)
 if recovered:
  q=read(R/recovered['source']);fig,axs=plt.subplots(1,2,figsize=(12,4))
  for c in q['Candidates']:
   p=c['Points'];axs[0].plot([v['Rider']['TotalReferenceMeters'] for v in p],[v['Rider']['Road']['OffsetMeters'] for v in p],label=c['Origin'].split('/')[-1]);axs[1].plot([v['Time'] for v in p],[v['Rider']['Speed']*3.6 for v in p],label=c['Origin'].split('/')[-1])
  axs[0].set(xlabel='reference [m]',ylabel='offset [m]');axs[1].set(xlabel='forecast time [s]',ylabel='speed [km/h]')
  for ax in axs:ax.legend();fig.tight_layout()
  fig.savefig(out/'maneuvers.png',dpi=150);plt.close(fig)
 if a['native']:
  replay=read(D/'native-replay.json.gz');g=replay['geometry'];fig,ax=plt.subplots(figsize=(12,6))
  for edge in ['Inner','Outer']:
   p=g['Boundaries'][edge];ax.plot([s['X'] for s in p],[s['Y'] for s in p],c='#444',lw=1)
  for r in replay['runs']:
   p=r['samples'];ax.plot([s['x'] for s in p],[s['y'] for s in p],lw=.8,label=r['name']+' '+r['status'])
  ax.set(aspect='equal',xlabel='x [m]',ylabel='y [m]',title='Actual original native paths only');ax.legend(fontsize=7);fig.tight_layout();fig.savefig(out/'native-xy.png',dpi=150);plt.close(fig)
def report(a):
 p=[];add=p.append;hist=read(D/'historical-forensics.json.gz');native=a['native'];held=[q for q in native if q['validation']]
 add('# Badanie #161 — trajektoria i wykonalność kontynuacji\n')
 add(f"**Werdykt: {a['verdict']}.** Baza dokładna `{a['base']}`. PROVISIONAL, domyślnie OFF, osobny Draft PR, bez merge. Prognozy i certyfikaty nie są ukończeniami natywnymi.\n")
 add('## Pięć odpowiedzi\n')
 add('1. **Dlaczego #160 nie znalazł kontynuacji?** V6 usuwa nielegalną różnicę skończoną v5, ale profil prędkości nadal używa `Planner146.Goal(...,3)`, który obcina podgląd krzywizny metą. Rezerwa wymaga jeszcze 32 m. W zachowanej prognozie z 67 s pierwsze żądanie 38,376 m/s pojawia się przy prognozowanym t=74,6 s i referencji 925,155 m. Potem cel skacze do25,507 m/s; po jego obniżeniu optymalizator pozostaje przy gazie1. Powstaje niestabilna końcówka rezerwy. To przyszłe komendy diagnostyczne, niewykonane po rzeczywistym DNF67.\n')
 add('2. **Algorytm czy fizyka?** Głównie ograniczenie generatora, przy niekorzystnym stanie fizycznym: offset0,679 m, prędkość do wewnątrz1,413 m/s i β≈0 nie oznaczają bezpiecznego kierunku ruchu. Nowy generator znajduje z dokładnie tego stanu trzy legalne kontynuacje z pełną kolejką i rezerwą988,336 m. Przy67 s nie było zatem za późno dla znalezionego manewru. Nie jest to dowód globalnej granicy osiągalności.\n')
 completed=[q for q in native if q['pass_']];add(f"3. **Rzeczywiste S3 szybciej niż #158?** Nowe światy {len(native)}, ukończenia {len(completed)}, DNF {sum(not q['pass_'] for q in native)}. "+('Rozwojowe S3: '+n(completed[0]['finish_s'])+' s, baza '+n(completed[0]['pair']['baseline_finish_s'])+' s.\n' if completed else 'Brak nowego ukończenia S3; PARTIAL.\n'))
 add(f"4. **Pięć warunków?** Wykonano {len(held)}/5 wcześniej ustalonych różnych walidacji; DNF {sum(not q['pass_'] for q in held)}. Mediana ukończeń {n(a['median_finish_s'])} s; rozrzut {a['finish_range_s']}. PASS wymaga kompletu pięciu par i przewagi czasowej, po zamrożeniu źródeł.\n")
 add('5. **CPU i większa prędkość:** koszty podano dla każdej próby i fazy. Pozostaje konserwatywny budżet propozycji siły normalnej, ograniczona liczba manewrów, zasięg aktuatora i pełne rezerwy 13/9. Nie szukano kolejnego rekordu, nie zwiększano siły silnika ani opon, nie wyznaczono globalnego optimum.\n')
 add('## Granica wiedzy o historycznym DNF\n')
 add('Odzyskano pełny fizyczny stan67 s oraz wejścia 10 taśm portfolio z ostatniego zaakceptowanego review66,8 s: nominalna i dziewięć warunkowych, ich kolejność, akcje, początki, cele oraz hash fizyczny. `Remember` usuwa wcześniejsze portfolio i zapisuje ten komplet. Nie zachowano gęstych tablic przyszłych stanów, wszystkich cache ani snapshotu nieudanej callback przy67 s. To rekonstrukcja stanu i struktury wejść portfolio, **nie bitowo dokładne odtworzenie całego procesu decyzyjnego**. Nie przedstawiamy świeżego planera jako repliki starego portfolio.\n')
 add('W66,8 s zaakceptowany safetyGoal wynosił956,336 m, czyli metę. Przy przejściu celu w67 s wymagany jest988,336 m. Poprzednie certyfikaty nie sprawdzały tego nowego końca. Najwcześniejsza udokumentowana utrata zdolności tej rodziny generatora do obsługi nowego obowiązku występuje przy tej zmianie celu; nie dowiedziono wcześniejszej fizycznej utraty osiągalności. Ponieważ nowa kontynuacja działa już z ostatniego zapisanego stanu67 s, jest to najpóźniejszy znaleziony autentyczny stan. Cofanie kolejnych review nie dostarczyłoby późniejszej granicy i nie zostało uruchomione.\n')
 add('![Ostatnie20s rzeczywistych stanów](plots/last20-native.png)\n![Przyczyna w prognozie rezerwy](plots/terminal-cause.png)\n')
 add('## Zmiany algorytmu i numeryka\n')
 add('Podgląd profilu obejmuje dwa następne pełne fizyczne łuki w okresowej geometrii także za metą. Nie skraca się safetyGoal ani dystansu biegu. Gdy opóźniony stan jest za szybki lub skierowany do granicy, lokalny strzelający optymalizator ocenia także legalne odjęcie gazu; nasycenie nie jest jedynym punktem startowym Newtona. Stan przestrzenny zawiera XY i obrys obu granic, offset i prędkość poprzeczną, θχβyaw, wykonany skręt, gaz, napęd i pełne pending.\n')
 add('Generator porównuje najwyżej trzy różne manewry: Track — docelowa linia i jazda; Prepare — linia z prognozowanego położenia, wcześniejsza redukcja przy ruchu poprzecznym; Recover — odjazd od bliższej granicy, dłuższe uspokojenie i odjęcie gazu przed zmianą kierunku. Linie2,5 m lub width−3 są propozycjami korytarza, nie nowymi granicami bezpieczeństwa. Wybór: najmniejszy fizycznie obliczony czas do wspólnego celu spośród pełnych legalnych rezerw. Każda nielegalna lub nieukończona propozycja zostaje odrzucona osobno. Brak nagrody za Vmax, gaz1 lub β0.\n')
 add('W feedback przywrócono wspólną korektę yaw i oryginalnej prędkości poślizgu tylnego koła; β i kierunek ruchu nadal pozostają osobnymi wielkościami. Wszystkie odpowiedzi używają oryginalnych kontaktów, rzeczywistego skrętu, wału i koła. Pochodne gazu i skrętu są ograniczone do fizycznego zakresu z rzeczywistym mianownikiem; dotyczy to również dawnego `actual±0,005`. Brak wiarygodnej pochodnej daje legalną propozycję feed-forward i jawny licznik, nigdy certyfikat. Wyjątki fizyki i niezmienników nie są zamieniane w sukces.\n')
 add('Planner161 powstaje mechanicznie z zamrożonego Planner160 przez zmianę haków propozycji. Runtime158, 13 węzłów/9 pełnych rezerw, niezależne odtworzenie, opóźnienie0,24 s, review0,2 s, aktuator, β45, obrys/swept0,5 m i Box2D pozostają identyczne. Wyłączono opcjonalne korzenie dodające gaz do zachowanego planu; czas porównuje generator pełnych manewrów. OFF deleguje bezpośrednio do oryginalnego kontrolera.\n')
 add('## Diagnostyki i alternatywy\n')
 for q in a['diagnostics']:
  add(f"### {q['Label']} — stan t={n(q['InitialTime'])} s\n")
  add(table(['Manewr','Legalny','Przybycie do celu [s]','Koniec ref [m]','Swept [m]','CPU [s]','Powód'],[[x['Maneuver'],x['Legal'],n(x['Arrival']),n(x['EndReference']),n(x['Sweep']),n(x['CpuSeconds']),x['Reason']] for x in q['Outcomes']]))
  add(table(['Wariant','Offset min/max [m]','Vmax [km/h]','Hash komend (skrót)'],[[x['origin'].split('/')[-1],n(x['minimum_offset'])+' / '+n(x['maximum_offset']),n(x['maximum_speed_kph']),x['actions_sha256'][:16]] for x in q['candidates']]))
 add('W odzyskaniu67 s wszystkie trzy warianty są legalne, najszybszy Track wygrywa uczciwe porównanie czasu. Nie wymuszano wyboru wolniejszego wariantu dla demonstracji. Profile linii, prędkości i hashe komend są różne. Recover od startu nie kończy pełnego dystansu w limicie450 review/90 s i pozostaje odrzuconą niepełną prognozą, mimo zachowanych marginesów. Nie jest to dowód fizycznej niemożliwości wolniejszej jazdy.\n![Różne manewry](plots/maneuvers.png)\n')
 add('## Certyfikacja\n');add(table(['Probe','Stan','13/9 + independent','CPU [s]'],[[q['label'],q['fixture'],q['pass_'],n(q['cpu_s'])] for q in a['certificates']]))
 add('## Natywne wyniki i pełne pary\n');add(table(['Próba','Status','S3 [s]','Baza [s]','Δ [s]','Pose [m]','Swept [m]','βmax [°]','CPU [s]'],[[q['label'],'S3' if q['pass_'] else 'DNF',n(q['finish_s']),n(q['pair']['baseline_finish_s']),n(q['pair']['delta_s']),n(q['minimum_pose_m']),n(q['minimum_swept_m']),n(q['maximum_beta_deg']),n(q['cpu_process_s'])] for q in native]))
 for q in native:
  add('### '+q['label']+'\n');add('Czasy okrążeń [s]: '+', '.join(n(t) for t in q['laps_s'])+f". Droga XY {n(q['distance_xy_m'])} m. Komendy z pełnym certyfikatem {q['accepted_decisions']}, ABSTAIN {q['abstain']}, kontakty {q['contacts']}, odrzucenia planów {len(q['rejected_plans'])}.\n")
  add(table(['Łuk','Stan','Wejście [km/h]','Vmin [km/h]','Wyjście [km/h]','Czas [s]'],[[b['bend'],b['status'],n(b['entry']['speed_kph']) if b['entry'] else '—',n(b['minimum_kph']),n(b['exit']['speed_kph']) if b['exit'] else '—',n(b['duration_s'])] for b in q['six_bends']]))
  add(table(['Okr./prosta','Czas obserwacji [s]','Średnia [km/h]','Vmax [km/h]'],[[str(s['lap'])+'/'+str(s['section']),n(s['observed_s']),n(s['mean_kph']),n(s['maximum_kph'])] for s in q['straights']]))
  add(f"CPU callbacków: suma {n(q['cpu_callbacks']['total'])}, mediana {n(q['cpu_callbacks']['median'])}, maksimum {n(q['cpu_callbacks']['maximum'])} s. Fazy: "+', '.join(f'{k}={v:.3f}s' for k,v in q['cpu_phases'].items())+'. Fazy zagnieżdżone nie są dodatkowym kosztem do sumy callbacków.\n')
  add('Źródła wybranych planów: '+json.dumps(q['selected_origins'],ensure_ascii=False)+'. Szczegóły rzeczywistych generacji i odrzuceń zachowuje analysis.json i każdy policy DAG.\n')
  for failure in q['failures']:add('Odmowa: `'+failure['reason']+'` przy t='+n(failure['time'])+' s.\n')
 add('![Tylko rzeczywiste trajektorie](plots/native-xy.png)\n')
 add('## Budżet i granice dowodu\n');add(table(['Rodzaj','Wykonano','CPU rozliczone [s]','Limit liczby'],[[k,sum(r['Kind']==k for r in a['budget']),sum(r['ChargedCpuSeconds'] for r in a['budget'] if r['Kind']==k),limit] for k,limit in [('diagnostic',6),('certificate',2),('native',6)]]))
 add('Przed uruchomieniami: diagnostyki6 / 360 CPU-s, maks90 CPU-s na diagnostykę i trzy jawne alternatywy; certyfikacje2×60 CPU-s; jeden świat rozwojowy i tylko po jego sukcesie pięć odłożonych, każdy maks2400 CPU-s, łącznie14400 CPU-s; review60 CPU-s. Nie podnoszono budżetu. Obowiązkowe certyfikacje każdej natywnej komendy wchodzą do CPU biegu; dwie próby odnoszą się do osobnych probe przed światem. Historyczny audyt jest odczytem istniejących danych, bez prognoz. Nie uruchamiano prób dla wykorzystania pozostałego limitu.\n')
 add('Pełne stany początkowe, specyfikacje, masa i bezwładność w parach są identyczne; zamrożone drzewa fizyki, geometrii i historii nie zmieniły się. Pięć walidacji to pierwsze pięć różnych warunków final-v6 #158, określonych przed wynikami; rozwój nie jest szóstym niezależnym warunkiem. DNF pozostaje w mianowniku, nie otrzymuje fikcyjnego czasu mety.\n')
 add('CSV.gz przechowuje100Hz: XY/drogę, offset i prędkość poprzeczną, θχβyaw i krzywiznę rzeczywistej trajektorii, żądany/aktywny gaz i skręt, wheelspin, siły obu opon, wykorzystanie przyczepności, wał/sprzęgło, obrys/swept i pełne pending. Sekcje pomiarowe mają interpolowane czasy przecięcia granic; replay wybiera wyłącznie zapisane oryginalne próbki i indeksy. Historyczny160 kończy się przy67 s — niczego po DNF nie dopisano.\n')
 text='\n'.join(p);(D/'REPORT.md').write_text(text,encoding='utf-8',newline='\n')
 import markdown
 body=markdown.markdown(text,extensions=['tables','fenced_code'])
 for img in (D/'plots').glob('*.png'):body=body.replace('src="plots/'+img.name+'"','src="data:image/png;base64,'+base64.b64encode(img.read_bytes()).decode()+'"')
 css='body{font:16px/1.6 system-ui;color:#183342;max-width:1180px;margin:36px auto;padding:0 24px}h1,h2,h3{line-height:1.25}h2{margin-top:2.4em}table{display:block;overflow:auto;border-collapse:collapse;font-size:13px}th,td{padding:8px;border-bottom:1px solid #d5e0e6;text-align:left}th{background:#eef4f7}img{max-width:100%}code{overflow-wrap:anywhere}'
 (D/'report.html').write_text('<!doctype html><html lang="pl"><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>Badanie161 — raport</title><style>'+css+'</style><body>'+body+'</body></html>',encoding='utf-8')
def replay():
 data=read(D/'native-replay.json.gz');template=(R/'tools/dynamic-slip-preview/replay160.html').read_text(encoding='utf-8').replace('Badanie #160','Badanie #161').replace('Badanie 160','Badanie 161');model=(R/'tools/replay-viewer/study160-model.mjs').read_text(encoding='utf-8').replace('export function','function');template=template.replace('let selected=0,time=0','let selected=Math.min(1,data.runs.length-1),time=0').replace('draw();requestAnimationFrame(frame);',"$('run').value=String(selected);draw();requestAnimationFrame(frame);")
 (D/'replay.html').write_text(template.replace('/*MODEL160*/',model).replace('/*DATA160*/',json.dumps(data,separators=(',',':'))),encoding='utf-8')
if __name__=='__main__':
 a=read(D/'analysis.json');plots(a);report(a);replay()
