using System.Diagnostics;
using System.Text.Json.Nodes;
using LineThrottle156;
namespace Dynamic160;
public sealed class Budget160:IDisposable {
 readonly string label,kind;readonly Process process=Process.GetCurrentProcess();readonly double start,cap;bool done;
 static string FileName=>Path.Combine(Program160.Doc,"budget-journal.json");
 public double Elapsed=>process.TotalProcessorTime.TotalSeconds-start;
 public Budget160(string label,string kind="diagnostic"){
  this.label=label;this.kind=kind;start=process.TotalProcessorTime.TotalSeconds;
  if(!File.Exists(Path.Combine(Program160.Doc,"budget-plan.json")))throw new IOException("Declare budget first");
  var rows=Read();if(rows.Any(r=>r!["Label"]!.GetValue<string>()==label))throw new IOException("Preserve existing attempt");
  if(rows.Any(r=>!r!["Complete"]!.GetValue<bool>()))throw new IOException("Unfinished reservation; inspect owner before continuing");
  var plan=JsonNode.Parse(System.IO.File.ReadAllText(Path.Combine(Program160.Doc,"budget-plan.json")))!;
  int count=rows.Count(r=>r!["Kind"]!.GetValue<string>()==kind);
  int limit=plan[kind=="diagnostic"?"MaximumDiagnosticContinuations":kind=="certificate"?"MaximumCertificateProbes":"MaximumNewNativeWorlds"]!.GetValue<int>();
  double used=rows.Where(r=>r!["Kind"]!.GetValue<string>()==kind).Sum(r=>r!["ChargedCpuSeconds"]!.GetValue<double>());
  cap=kind=="diagnostic"?plan["DiagnosticCpuCapSeconds"]!.GetValue<double>()-used:kind=="certificate"?60:Math.Min(1800,19800-used);
  if(count>=limit||cap<=0)throw new InvalidOperationException("STUDY160_DECLARED_BUDGET_EXHAUSTED");
  rows.Add(new JsonObject{["Label"]=label,["Kind"]=kind,["Complete"]=false,["ChargedCpuSeconds"]=cap,["CpuCapSeconds"]=cap,["ProcessId"]=process.Id});Write(rows);
 }
 static JsonArray Read()=>File.Exists(FileName)?JsonNode.Parse(File.ReadAllText(FileName))!.AsArray():new();
 static void Write(JsonArray rows){File.WriteAllText(FileName+".next",rows.ToJsonString(Study156.Json));File.Move(FileName+".next",FileName,true);}
 public void Guard(){if(Elapsed>=cap)throw new InvalidOperationException("STUDY160_CPU_STOP");}
 public void Finish(string reason){if(done)return;var rows=Read();var row=rows.Single(r=>r!["Label"]!.GetValue<string>()==label)!;row["Complete"]=true;row["CpuSeconds"]=Elapsed;row["ChargedCpuSeconds"]=Math.Ceiling(Elapsed+1);row["Reason"]=reason;Write(rows);done=true;}
 public void Dispose()=>Finish("attempt ended; negative evidence retained");
}
