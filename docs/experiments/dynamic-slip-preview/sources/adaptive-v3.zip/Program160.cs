using System.Diagnostics;
using System.IO.Compression;
using System.Numerics;
using System.Text.Json;
using Autonomous146;
using CoreSim;
using Efficient152;
using LineThrottle156;
using Safety153;
using SharedWorldSpeedway;
using ThreeLap158;
namespace Dynamic160;
public static class Program160 {
 public const string Base="9fb071ba3129aae88a6ec8c401d51a784be2da2b";
 public static string Doc=>Path.Combine(Study156.Root,"docs/experiments/dynamic-slip-preview");
 public static void Save(string path,object o)=>Study156.Save(Path.Combine(Doc,path),o);
 public static int Main(string[] args){try{if(args.Length<2||args[0]!="--forecast")throw new ArgumentException("Study160 OFF: explicit --forecast unique-label [settings-json] [goal] required");var settings=args.Length>2?JsonSerializer.Deserialize<Settings160>(args[2],Study156.Json)!:new();Forecast(args[1],settings,args.Length>3?double.Parse(args[3],System.Globalization.CultureInfo.InvariantCulture):3*StandingWorld144.Frame().LapMeters);return 0;}catch(Exception e){Console.Error.WriteLine(e);return 1;}}
 public static object Trace(State146 state,FreeRacingAction action,Control158 old,Runtime158 rt){
  var s=old.ActivationState(state);var v=s.Input.Rider;var nominal=rt.Frame.At(v.TotalReferenceMeters,old.TargetOffset(v.TotalReferenceMeters));var road=nominal.Road;double k=road.IsTurn?1/road.RadiusMeters:0,e=Vector2.Dot(v.Position-nominal.Position,road.Outward),vy=Vector2.Dot(v.Velocity,road.Outward);var o=old.Settings;
  var imagined=old.Response(s,action.SteeringRadians,action.Drive);var shaft=new CrankClutch144(omega:s.CrankOmega);var q=Contact144.Forces(v with{Drive=action.Drive},rt.Spec,rt.Frame,MultiActionExperiment135.Surface(rt.Frame),FreeLearningExperiment.Parameters(),s.Input.Time,147,Speed148.ForecastFork148.Wheel(s.Input.Omega),new(s.Input.Steering),.01f,steeringOverride:action.SteeringRadians,inertia:52.72097f,powertrain:shaft,releaseAt:.24);
  var tangent=v.Speed>.1?Vector2.Normalize(v.Velocity):road.Tangent;double chiDot=v.Speed>.1?TwoContactForces.Cross(tangent,q.NetForce)/(147*v.Speed):0;
  return new{Time=state.Input.Time,ActivationTime=s.Input.Time,Speed=v.Speed,Theta=v.Heading,Chi=Math.Atan2(v.Velocity.Y,v.Velocity.X),Beta=v.SlideRadians,Yaw=v.AngularVelocity,ActualPathCurvature=v.Speed>.1?chiDot/v.Speed:0,RoadCurvature=k,CourseTerm=v.Speed*k+(e/o.CourseSeconds+2*vy)/(Math.Max(2,v.Speed)*o.CourseSeconds),BetaTerm=-v.SlideRadians/o.BetaSeconds,DesiredAlpha=(v.Speed*k+(e/o.CourseSeconds+2*vy)/(Math.Max(2,v.Speed)*o.CourseSeconds)-v.SlideRadians/o.BetaSeconds-v.AngularVelocity)/o.YawSeconds,Action=action,Imagined=imagined,Actual=new{YawAcceleration=q.NetTorque/52.72097,ChiDot=chiDot,BetaDot=v.AngularVelocity-chiDot,AlongAcceleration=Vector2.Dot(q.NetForce,tangent)/147},Forces=q,Powertrain=shaft.Prepared,Pending=state.Input.Pending};
 }
 public static void Snapshot(string label){var target=Path.Combine(Doc,"sources",label+".zip");Directory.CreateDirectory(Path.GetDirectoryName(target)!);using var z=System.IO.Compression.ZipFile.Open(target,System.IO.Compression.ZipArchiveMode.Create);foreach(var file in Directory.GetFiles(Path.Combine(Study156.Root,"tools/dynamic-slip-preview")))z.CreateEntryFromFile(file,Path.GetFileName(file));}
 public static void Forecast(string label,Settings160 settings,double goal){using var budget=new Budget160(label);Snapshot(label);var spec=StandingWorld144.Rider(StartingGate.B);var rt=new Runtime158(spec,false,Hierarchical155.Program155.Options());var control=new Control160(rt,settings);var old=new Control158(rt,new(settings.DiagnosticSpeed,CourseSeconds:1));var initial=Program158.Initial(spec);var state=initial;var points=new List<FreeRacingPoint>();var actions=new List<object>();string reason="horizon";bool reached=false;string? error=null;
  try{for(int i=0;i<900;i++){budget.Guard();rt.Begin(state.Input.Time);control.Begin();var action=control.Action(state);actions.Add(new{State=state,Action=action,Trace=settings.Enabled?control.Last:Trace(state,action,old,rt)});var step=rt.Step(state,action);points.AddRange(step.Prediction.Points.Skip(points.Count==0?0:1));state=step.End;var safety=Clearance153.Check(step.Prediction.Points,Regime153.SafetyHalfMeter);if(!safety.Legal){reason=safety.Reason;break;}if(state.Input.Rider.TotalReferenceMeters>=goal){reached=true;reason="diagnostic goal";break;}}}catch(Exception e){error=e.ToString();reason=e.Message;}
  var check=Clearance153.Check(points.ToArray(),Regime153.SafetyHalfMeter);var summary=new{Label=label,Settings=settings,Reached=reached,Legal=check.Legal,Reason=reason,Error=error,EndTime=state.Input.Time,EndReference=state.Input.Rider.TotalReferenceMeters,MaximumSpeedKph=points.Select(p=>p.Rider.Speed*3.6).DefaultIfEmpty().Max(),Safety=check,CpuSeconds=budget.Elapsed,control.Predictions,control.ForceQueries};Save("forecasts/"+label+".json.gz",new{Summary=summary,Initial=initial,Goal=goal,End=state,Points=points,Actions=actions,Scope="Diagnostic forecast only; no native world and no13/9 certificate"});Console.WriteLine(JsonSerializer.Serialize(summary,Study156.Json));budget.Finish(reason);
 }
}
