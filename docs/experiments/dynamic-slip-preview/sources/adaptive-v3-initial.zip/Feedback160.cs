using Autonomous146;
using Robust150;
using SharedWorldSpeedway;
using ThreeLap158;
namespace Dynamic160;
public static class Feedback160 {
 public static FreeRacingAction Action(Runtime158 rt,State146 observed,Tape150 ownPlan,Control160 control){
  var k=Math.Clamp((int)Math.Round((observed.Input.Time-ownPlan.CreatedAt)/.2),0,ownPlan.Actions.Length-1);
  if(Efficient147.ExactKey147.State(observed)==Efficient147.ExactKey147.State(ownPlan.States[k]))return ownPlan.Actions[k];
  return control.Action(observed);
 }
}
