"""Mechanical153 adapters. Original physics and153 sources are never modified."""
from pathlib import Path
import sys
R=Path(__file__).resolve().parents[2];D=Path(__file__).parent
def emit(name,s):
 s='// Generated mechanically from frozen study153; see generate154.py.\n'+s
 p=D/name
 if '--check' in sys.argv:assert p.read_text(encoding='utf-8')==s,name
 else:p.write_text(s,encoding='utf-8',newline='\n')
for kind in ('Runtime','Planner','Feedback'):
 s=(R/f'tools/safe-fast-contingency/{kind}153.Generated.cs').read_text(encoding='utf-8')
 s=s.replace('namespace Safety153;','namespace Viable154;\nusing Safety153;')
 for name in ('Runtime','Planner','Feedback'):s=s.replace(name+'153',name+'154')
 s=s.replace('RuntimeOptions153','RuntimeOptions154')
 if kind=='Runtime':
  s=s.replace('bool StrictSeeds=false);','bool StrictSeeds=false,int CandidateMode=0);')
  s=s.replace(' public Decision144 Seed(State146 state)=>a is not null?a.Seed(state):b!.Seed(state);',''' public long ViableSeedCalls,ViableCandidateForecasts,LocalPoseRejected,LocalSweepOnlyRejected,LocalLegalCandidates;
 public Decision144 OriginalSeed(State146 state)=>a is not null?a.Seed(state):b!.Seed(state);
 public FreeRacingPrediction CandidateForecast(State146 state,FreeRacingAction action)=>a is not null?a.ForecastForDiagnostics(state,action,.9):b!.ForecastForDiagnostics(state,action,.9);
 public int CandidateMode=>options.CandidateMode;
 public Decision144 Seed(State146 state){if(options.CandidateMode==0)return a is not null?a.Seed(state):b!.Seed(state);ViableSeedCalls++;return Candidate154.Choose(this,state);}
''')
  s=s.replace('Verification="Fresh per-review DAG;', 'ViableSeedCalls,ViableCandidateForecasts,LocalPoseRejected,LocalSweepOnlyRejected,LocalLegalCandidates,Verification="Fresh per-review DAG;')
 if kind=='Planner':
  s=s.replace('STUDY153','STUDY154')
 emit(kind+'154.Generated.cs',s)
print('Study154 generated-source parity PASS' if '--check' in sys.argv else 'Generated154 adapters')
