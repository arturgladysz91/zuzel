using System.Numerics;
using CoreSim.PhysicalSpace;
using Autonomous146;
using SharedWorldSpeedway;
namespace Viable154;
/// <summary>Geometry lookahead proposes controls only. No cheap estimate is a certificate.
/// Speed and centre corridor are conservative proposal targets, not physics changes.</summary>
public static class Candidate154 {
 public const double TargetSpeedMetersPerSecond=15,LookaheadSeconds=.9,YawResponseSeconds=.5;
 public static Decision144 Choose(Runtime154 rt,State146 state){
  var watch=System.Diagnostics.Process.GetCurrentProcess().TotalProcessorTime;
  // Irrevocable0.2s prefix is propagated with the original provider. A new action
  // has0.24s delay and cannot affect this prefix; its dummy queue is not consulted.
  var future=rt.Step(state,new(0,0)).End;var v=future.Input.Rider;
  var road=v.Road;var frame=rt.Frame;
  var targetOffset=(frame.Track.Geometry.StraightWidthMeters-2)/2;
  var lookahead=3+Math.Max(3,v.Speed)*LookaheadSeconds;
  var ahead=frame.At(road.ReferenceMeters+lookahead,targetOffset).Position;
  var delta=ahead-v.Position;var angle=Math.Atan2(delta.Y,delta.X);
  var yawRate=2*Math.Max(v.Speed,1)*Math.Sin(BikeAngles.Wrap(angle-v.Heading))/Math.Max(delta.Length(),1);
  var desiredAlpha=(yawRate-v.AngularVelocity)/YawResponseSeconds;
  float drive=v.Speed<TargetSpeedMetersPerSecond-.3?1f:v.Speed>TargetSpeedMetersPerSecond+.3?0:.25f;
  if(state.Input.Time<=RiderController.ReactionSeconds(rt.Spec))drive=1;
  var max=TwoContactBikeParameters.Default.MaximumSteeringRadians;
  var centre=Math.Clamp(future.Input.Steering,-max,max);var eps=.5f*MathF.PI/180;
  var lo=Math.Clamp(centre-eps,-max,max);var hi=Math.Clamp(centre+eps,-max,max);
  var action=new FreeRacingAction(centre,drive);
  var alpha=rt.LocalAlpha(future,action,centre);var derivative=(rt.LocalAlpha(future,action,hi)-rt.LocalAlpha(future,action,lo))/(hi-lo);
  var steering=double.IsFinite(derivative)&&Math.Abs(derivative)>1e-8?Math.Clamp(centre+(desiredAlpha-alpha)/derivative,-max,max):centre;
  if(v.Speed<2)steering=0;
  return new(new(state.Input.Time,new((float)steering,drive),FreeActionSafety.SafeInHorizon,false,Array.Empty<FreeLearningCandidate>(),3,1),(System.Diagnostics.Process.GetCurrentProcess().TotalProcessorTime-watch).TotalSeconds);
 }
}
