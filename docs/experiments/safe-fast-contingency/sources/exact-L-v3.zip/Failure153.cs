using Contingency151;
using Robust150;
namespace Safety153;
public static class Failure153 {
 public static object? First(Tape150 tape,Regime153 regime){
  if(regime==Regime153.Legacy)return Audit151.FirstFailure(tape);
  for(int j=0;j<tape.Points.Length;j++){
   var p=tape.Points[j];var s=Clearance153.Check(j==0?new[]{p}:new[]{tape.Points[j-1],p},regime);
   if(!s.Legal)return new{Time=p.Time,Reference=p.Rider.TotalReferenceMeters,p.Inner,p.Outer,s.SweepLowerBoundMeters,s.MaximumBetaDegrees,s.Reason};
  }
  return null;
 }
}
