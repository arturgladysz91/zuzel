using System.Numerics;
using Autonomous146;
using CoreSim.PhysicalSpace;
using Efficient152;
using Safety153;
using SharedWorldSpeedway;
namespace ThreeLap158;

public sealed record Settings158(double SpeedMetersPerSecond=12,double OffsetMeters=5,
 double CourseSeconds=.8,double YawSeconds=.6,double BetaSeconds=.8,double PreviewSeconds=.8,bool PredictPending=true);
public sealed record Response158(double YawAcceleration,double LongitudinalAcceleration,double LateralAcceleration);

/// <summary>Only current observations, immutable geometry and original contact/predictor
/// calls. No demonstrations, saved commands, body writes or parameter substitution.</summary>
public sealed class Control158 {
 readonly Runtime153 rt;readonly CoreSim.TrackStateSnapshot surface;readonly WorldParameters parameters;
 readonly Boundary152 boundary;readonly Dictionary<string,State146> prefixes=new();
 public Settings158 Settings{get;}public long PrefixForecasts,ForceQueries,JointCorrections;
 public Control158(Runtime153 runtime,Settings158? settings=null){rt=runtime;Settings=settings??new();surface=MultiActionExperiment135.Surface(rt.Frame);parameters=FreeLearningExperiment.Parameters();boundary=new(rt.Frame);}
 public void Begin(){prefixes.Clear();}
 public State146 ActivationState(State146 state){if(!Settings.PredictPending)return state;var key=Efficient147.ExactKey147.State(state);if(prefixes.TryGetValue(key,out var hit))return hit;double crank=state.CrankOmega;PrefixForecasts++;
  var p=PredictorA153.Predict(state.Input,rt.Spec,rt.Frame,surface,parameters,147,52.72097f,.24,null,powertrain:new(omega:state.CrankOmega),observeCrank:(_,w)=>crank=w,fastBoundary:boundary,exactInitialWheel:true);
  var end=p.Points[^1];var queue=state.Input.Pending.OrderBy(c=>c.ActivationAt).ToArray();var active=queue.Where(c=>c.ActivationAt<=end.Time+1e-10).Select(c=>c.Action).LastOrDefault(state.Input.Active);
  return prefixes[key]=new(new(end.Rider with{Drive=active.Drive},end.Time,end.Omega,end.Steering,active,queue.Where(c=>c.ActivationAt>end.Time+1e-10).ToArray(),end.Time),crank);
 }
 public Response158 Response(State146 state,float steer,float drive){ForceQueries++;var v=state.Input.Rider with{Drive=drive};var wheel=Speed148.ForecastFork148.Wheel(state.Input.Omega);var shaft=new CrankClutch144(omega:state.CrankOmega);
  var q=Contact144.Forces(v,rt.Spec,rt.Frame,surface,parameters,state.Input.Time,147,wheel,new(steer),.01f,steeringOverride:steer,inertia:52.72097f,powertrain:shaft,releaseAt:.24);
  var tangent=v.Speed>.1?Vector2.Normalize(v.Velocity):v.Road.Tangent;var left=new Vector2(-tangent.Y,tangent.X);return new(q.NetTorque/52.72097f,Vector2.Dot(q.NetForce,tangent)/147,Vector2.Dot(q.NetForce,left)/147);
 }
 public FreeRacingAction Action(State146 observed){var state=ActivationState(observed);var v=state.Input.Rider;var o=Settings;
  if(v.Speed<2)return new(0,1);
  var ahead=Math.Max(2,v.Speed*o.PreviewSeconds);var target=rt.Frame.At(v.TotalReferenceMeters+ahead,o.OffsetMeters).Position;
  var desiredCourse=Math.Atan2(target.Y-v.Position.Y,target.X-v.Position.X);var course=Math.Atan2(v.Velocity.Y,v.Velocity.X);var error=BikeAngles.Wrap(course-desiredCourse);
  var road=rt.Frame.RoadAt(v.TotalReferenceMeters,o.OffsetMeters);var curvature=road.IsTurn&&double.IsFinite(road.RadiusMeters)?1/road.RadiusMeters:0;
  var desiredYaw=v.Speed*curvature-error/o.CourseSeconds+v.SlideRadians/o.BetaSeconds;
  var desiredAlpha=(desiredYaw-v.AngularVelocity)/o.YawSeconds;var desiredAcceleration=Math.Clamp((o.SpeedMetersPerSecond-v.Speed)/1.2,-2,3);
  float steer=state.Input.Steering,drive=state.Input.Active.Drive;var max=TwoContactBikeParameters.Default.MaximumSteeringRadians;
  // Simultaneously invert yaw and along-velocity acceleration using the ORIGINAL
  // contact equations. These are proposals; full physical certification owns safety.
  for(int k=0;k<3;k++){var a=Response(state,steer,drive);var lo=Math.Max(-max,steer-.5f*MathF.PI/180);var hi=Math.Min(max,steer+.5f*MathF.PI/180);var dl=Math.Max(0,drive-.05f);var dh=Math.Min(1,drive+.05f);var l=Response(state,lo,drive);var h=Response(state,hi,drive);var b=Response(state,steer,dl);var c=Response(state,steer,dh);
   var j11=(h.YawAcceleration-l.YawAcceleration)/(hi-lo);var j21=(h.LongitudinalAcceleration-l.LongitudinalAcceleration)/(hi-lo);var j12=(c.YawAcceleration-b.YawAcceleration)/(dh-dl);var j22=(c.LongitudinalAcceleration-b.LongitudinalAcceleration)/(dh-dl);var determinant=j11*j22-j12*j21;
   var e1=desiredAlpha-a.YawAcceleration;var e2=desiredAcceleration-a.LongitudinalAcceleration;if(!double.IsFinite(determinant)||Math.Abs(determinant)<1e-7){if(Math.Abs(j11)>1e-7)steer=(float)Math.Clamp(steer+Math.Clamp(e1/j11,-.05,.05),-max,max);drive=(float)Math.Clamp(drive+Math.Sign(e2)*.05,0,1);continue;}
   steer=(float)Math.Clamp(steer+Math.Clamp((e1*j22-j12*e2)/determinant,-.05,.05),-max,max);drive=(float)Math.Clamp(drive+Math.Clamp((j11*e2-j21*e1)/determinant,-.2,.2),0,1);JointCorrections++;
  }
  return new(steer,drive);
 }
}
