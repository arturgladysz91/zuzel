using System.Diagnostics;
using System.Text.Json;
using System.Text.Json.Nodes;
using Autonomous146;
using LineThrottle156;
using Safety153;
using SharedWorldSpeedway;
namespace ThreeLap158;
public static class Program158 {
 public const string Base="7c24c31dd8587889ff2459608c328fb865a541ef";
 public static string Doc=>Path.Combine(Study156.Root,"docs/experiments/robust-three-lap");
 public static JsonSerializerOptions Json=>Study156.Json;
 public static void Save(string name,object value)=>Study156.Save(Path.Combine(Doc,name),value);
 public static int Main(string[] args){try{if(args.Length!=2||args[0] is not ("--diagnostic" or "--probe" or "--native-new" or "--native-base"))throw new ArgumentException("Study158 OFF; --diagnostic unique-label");if(args[0].StartsWith("--native-")){Native158.Run(args[0]=="--native-base",args[1]);}else if(args[0]=="--probe")Probe(args[1]);else Diagnostic(args[1]);return 0;}catch(Exception e){Console.Error.WriteLine(e);return 1;}}
 public static State146 Initial(RiderSpec spec){var frame=StandingWorld144.Frame();var point=frame.At(spec.ReferenceMeters,spec.OffsetMeters);var road=frame.Project(point.Position);var v=new RiderView(spec.Profile.Id,point.Position,System.Numerics.Vector2.Zero,(float)road.Heading,0,road,spec.ReferenceMeters,0,RiderActivity.Racing,0,spec.OffsetMeters,0,frame.Context(road,spec.ReferenceMeters));return new(new(v,0,0,0,new(0,0),Array.Empty<FreeRacingCommand>(),0),new CrankClutch144().Omega);}
 static void Probe(string label){using var b=new Budget158(label,0,120);var spec=StandingWorld144.Rider(CoreSim.StartingGate.B);var state=Initial(spec);var planner=new Planner158(spec,false,new(Enabled:true,MaximumRoots:3),b.Guard);string? error=null;try{planner.Choose(state.Input,new(omega:state.CrankOmega));}catch(InvalidOperationException e){error=e.Message;}Save(label+".json.gz",new{Error=error,Review=planner.Last is null?null:Efficient152.Evidence152.Compact(planner.Last),Counters=planner.Runtime.Counters(),planner.Generator.Outcomes,planner.Generator.Rejections,planner.Generator.FurthestPartial,JointCalls=Feedback158.JointCalls,planner.Generator.Control.PrefixForecasts,planner.Generator.Control.ForceQueries});Console.WriteLine(label+" "+(error??"CERTIFIED")+" CPU="+b.Elapsed);b.Finish(error??"Fresh full13/9 independent certificate");}
 static void Diagnostic(string label){using var budget=new Budget158(label,0,240);var rows=new List<object>();var spec=StandingWorld144.Rider(CoreSim.StartingGate.B);var frame=StandingWorld144.Frame();
  foreach(var speed in new[]{10d,12d,14d})foreach(var course in new[]{.6,1d,1.5}){var rt=new Runtime153(spec,false,Hierarchical155.Program155.Options());var settings=new Settings158(SpeedMetersPerSecond:speed,CourseSeconds:course);var policy=new Control158(rt,settings);var state=Initial(spec);var pts=new List<FreeRacingPoint>();var decisions=new List<object>();string reason="forecast finish";rt.Begin(0);var entered=Process.GetCurrentProcess().TotalProcessorTime;
   for(int k=0;k<900;k++){budget.Guard();policy.Begin();var action=policy.Action(state);var q=rt.Step(state,action);var safety=Clearance153.Check(q.Prediction.Points,Regime153.SafetyHalfMeter);decisions.Add(new{State=state,Action=action,Safety=safety});pts.AddRange(q.Prediction.Points.Skip(pts.Count==0?0:1));state=q.End;if(!safety.Legal){reason=safety.Reason;break;}if(state.Input.Rider.TotalReferenceMeters>=3*frame.LapMeters)break;}
   var complete=state.Input.Rider.TotalReferenceMeters>=3*frame.LapMeters;var cpu=(Process.GetCurrentProcess().TotalProcessorTime-entered).TotalSeconds;var name=$"{label}-v{speed}-c{course.ToString(System.Globalization.CultureInfo.InvariantCulture)}";Save("diagnostics/"+name+".json.gz",new{Settings=settings,CompleteForecast=complete,Reason=reason,End=state,Points=pts,Decisions=decisions,CpuSeconds=cpu,policy.PrefixForecasts,policy.ForceQueries,policy.JointCorrections,Scope="Development forecast only; zero native worlds, no13/9 and not an S PASS"});rows.Add(new{Settings=settings,CompleteForecast=complete,Reason=reason,Time=state.Input.Time,Reference=state.Input.Rider.TotalReferenceMeters,CpuSeconds=cpu});Console.WriteLine($"{name}: {complete} {reason} t={state.Input.Time:F1} ref={state.Input.Rider.TotalReferenceMeters:F1} CPU={cpu:F2}");
  }Save(label+".json",rows);budget.Finish("causal state-feedback development forecasts only");
 }
}
public sealed class Budget158:IDisposable {
 readonly FileStream lease;readonly JsonArray rows;readonly JsonObject row;readonly double cap;readonly Process process=Process.GetCurrentProcess();bool done;
 string Path=>Program158.Doc+"/budget.json";public double Elapsed=>process.TotalProcessorTime.TotalSeconds;
 public Budget158(string label,int worlds,double operationCpuLimit){Directory.CreateDirectory(Program158.Doc);lease=new(Path+".lock",FileMode.OpenOrCreate,FileAccess.ReadWrite,FileShare.None);rows=File.Exists(Path)?JsonNode.Parse(File.ReadAllText(Path))!.AsArray():new();if(rows.Any(r=>!r!["Complete"]!.GetValue<bool>()||r!["Name"]!.GetValue<string>()==label))throw new IOException("Inspect unfinished or duplicate158 attempt");cap=operationCpuLimit;row=new(){["Name"]=label,["Complete"]=false,["NativeWorlds"]=worlds,["CpuSeconds"]=0,["OperationCpuCap"]=cap,["Base"]=Program158.Base};rows.Add(row);Write();}
 void Write()=>File.WriteAllText(Path,rows.ToJsonString(Program158.Json));
 public void Guard(){if(Elapsed>=cap)throw new InvalidOperationException("STUDY158_OPERATION_CPU_STOP");}
 public void Finish(string reason){if(done)return;row["Complete"]=true;row["CpuSeconds"]=Elapsed+1;row["Reason"]=reason;Write();done=true;}
 public void Dispose(){if(!done)Finish("exception; all negative work retained");lease.Dispose();}
}
