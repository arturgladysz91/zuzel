using System.Diagnostics;
using System.IO.Compression;
using System.Text.Json;
using Autonomous146;
using Contingency151;
using CoreSim;
using Efficient152;
using LineThrottle156;
using SharedWorldSpeedway;
using Transfer157;
namespace ThreeLap158;

public static class Native158 {
 public static void Run(bool baseline,string label,int scenario=0,bool validation=false){
  if(scenario is <0 or >4)throw new ArgumentException("Five frozen scenarios only");
  var scenarioRows=Study156.Read<JsonElement>(Path.Combine(Program158.Doc,"scenarios-frozen.json")).GetProperty("Scenarios");var condition=scenarioRows[scenario];
  var gate=Enum.Parse<StartingGate>(condition.GetProperty("Gate").GetString()!);var spec=StandingWorld144.Rider(gate) with{OffsetMeters=condition.GetProperty("OffsetMeters").GetSingle(),TargetOffsetMeters=condition.GetProperty("OffsetMeters").GetSingle()};
  if(validation&&!File.Exists(Path.Combine(Program158.Doc,"controller-freeze.json")))throw new InvalidOperationException("Freeze after first native S completion before validation");
  using var budget=new Budget158(label,1,1800);Sources(label);Planner158? next=null;Planner157? old=null;State146? first=null;var journal=new List<object>();int accepted=0,abstain=0;double progressAt=0;
  Decision144 Choose(FreeRacingInput input,CrankClutch144 crank,RiderSpec rider,TrackFrame frame,TrackStateSnapshot surface,WorldParameters p,float mass,float inertia,string variant){
   budget.Guard();first??=new(input,crank.Omega);var started=Process.GetCurrentProcess().TotalProcessorTime;
   if(baseline)old??=new(rider,false,new(Enabled:true),budget.Guard);else next??=new(rider,false,new(Enabled:true,MaximumRoots:3),budget.Guard);
   Decision144 result;string? error=null;
   try{result=baseline?old!.Choose(input,crank):next!.Choose(input,crank);}catch(InvalidOperationException e){error=e.Message;abstain++;result=null!;}
   var review=baseline?old!.Last:next!.Last;var counters=baseline?old!.Runtime.Counters():next!.Runtime.Counters();
   Program158.Save("policies/"+label+"/"+(error is null?"decision-"+accepted.ToString("D4"):"abstain")+".json.gz",new{Observed=new State146(input,crank.Omega),Error=error,Review=review is null?null:Evidence152.Compact(review),Counters=counters,JointCalls=Feedback158.JointCalls,ControlPrefixForecasts=next?.Generator.Control.PrefixForecasts??0,ControlForceQueries=next?.Generator.Control.ForceQueries??0,ControlPrefixContactQueries=next?.Generator.Control.PrefixContactQueries??0,PrefixCacheHits=next?.Generator.Control.PrefixCacheHits??0,Outcomes=next?.Generator.Outcomes,Rejections=next?.Generator.Rejections});
   var cpu=(Process.GetCurrentProcess().TotalProcessorTime-started).TotalSeconds;
   journal.Add(new{Time=input.Time,Reference=input.Rider.TotalReferenceMeters,Accepted=error is null,Reason=error??review!.Reason,Action=error is null?result.Choice.Action:(FreeRacingAction?)null,PlannerCpuSeconds=review?.CpuSeconds,CallbackCpuSeconds=cpu,Nodes=review?.Tree.Length??0,FullReserves=review?.Terminals.Length??0,Goal=review?.Goal,SafetyGoal=review?.SafetyGoal});
   if(error is not null)throw new InvalidOperationException(error);accepted++;
   if(input.Time>=progressAt){Console.WriteLine($"{label}: t={input.Time:F1} ref={input.Rider.TotalReferenceMeters:F1} v={input.Rider.Speed*3.6:F1} decisions={accepted} CPU={budget.Elapsed:F1}");progressAt=input.Time+5;}
   return result with{CpuSeconds=cpu};
  }
  Run144 run;using(var world=new NativeWorld156(new(Enabled:true,RequiredLaps:3,MaximumSeconds:180,SoloGate:gate),diagnosticRider:spec,safetyHalfMeter:true,safetyFrom:0))run=world.Run(label,"K1",Choose);
  Program158.Save("native/"+label+".json.gz",run);Program158.Save("journals/"+label+".json.gz",journal);var samples=run.Riders[0].Samples;var full=run.Riders[0].CompletedLaps==3&&run.Riders[0].FinishSeconds is not null;
  var pose=samples.Min(s=>Math.Min(s.Inner,s.Outer));var sweep=samples.Skip(1).Min(s=>s.Certificate??double.NegativeInfinity);var beta=samples.Max(s=>Math.Abs(s.Input.Rider.SlideRadians))*180/Math.PI;
  var legal=full&&run.Outcome=="completed"&&run.Contacts.Length==0&&pose>=.5&&sweep>=.5&&beta<=45&&abstain==0;
  Program158.Save("native/"+label+"-result.json",new{Label=label,Baseline=baseline,Validation=validation,Scenario=condition,Spec=spec,Initial=first,ExpectedInitial=Program158.Initial(spec),RequiredLaps=3,CompletedLaps=run.Riders[0].CompletedLaps,FinishSeconds=run.Riders[0].FinishSeconds,Pass=legal,Complete=full,MinimumPoseMeters=pose,MinimumSweepMeters=sweep,MaximumBetaDegrees=beta,Contacts=run.Contacts.Length,AcceptedDecisions=accepted,Abstain=abstain,run.Outcome,run.Fingerprint,run.TotalCpuSeconds,run.ControllerCpuSeconds,ChargedCpuSeconds=budget.Elapsed,Scope="ONE continuous original Box2D world from stopped start, three-lap target, autonomous decisions only, S from0; DNF never promoted"});
  Console.WriteLine($"{label}: PASS={legal} laps={run.Riders[0].CompletedLaps} time={run.EndSeconds:F6} {run.Outcome} CPU={budget.Elapsed:F1}");budget.Finish(run.Outcome);
 }
 static void Sources(string label){var dir=Path.Combine(Study156.Root,"tools/robust-three-lap");Directory.CreateDirectory(Path.Combine(Program158.Doc,"sources"));using var file=new FileStream(Path.Combine(Program158.Doc,"sources",label+".zip"),FileMode.CreateNew);using var archive=new ZipArchive(file,ZipArchiveMode.Create);foreach(var path in Directory.GetFiles(dir))archive.CreateEntryFromFile(path,Path.GetFileName(path),CompressionLevel.Optimal);}
}
