"""Recorded-evidence report and standalone replay. Never advances physics."""
from analyze158 import R,D,read,write
import csv,gzip,json,statistics,sys,time

def table(headers,rows):
 return '| '+' | '.join(headers)+' |\n|'+ '|'.join(['---']*len(headers))+'|\n'+''.join('| '+' | '.join(map(str,r))+' |\n' for r in rows)
def f(x,n=3):return '—' if x is None else f'{x:.{n}f}'
def status(r):return 'PASS S3' if r['pass_'] else 'DNF'

def render(tag):
 entered=time.process_time();a=read(D/'analysis.json');all_rows=a['trials'];new=[r for r in all_rows if r['phase']=='final-v6' and r['validation'] and not r['baseline']];base=[r for r in all_rows if r['phase']=='final-v6' and r['validation'] and r['baseline']];g=next((r for r in a['groups'] if r['phase']=='final-v6' and not r['baseline']),{});bg=next((r for r in a['groups'] if r['phase']=='final-v6' and r['baseline']),{})
 passed=g.get('all_pass',False);verdict=('PASS autonomii S: '+str(g.get('completed',0))+'/'+str(g.get('planned_trials',10))+' pełnych biegów. ' if passed else 'PARTIAL: końcowa seria nie spełnia wszystkich warunków PASS. ')+f"Baza ukończyła {bg.get('completed',0)}/{bg.get('attempts',0)}."
 parts=[];add=parts.append
 add('# Badanie #158 — autonomiczne trzy okrążenia\n\n**'+verdict+'**\n')
 add('Baza: Draft PR #156, dokładny HEAD `7c24c31dd8587889ff2459608c328fb865a541ef`. Gałąź `experiment/robust-three-lap-158`; kontroler i narzędzie domyślnie OFF, bez integracji produkcyjnej i bez merge. Status autonomii wynika wyłącznie z zapisanych natywnych biegów, a nie z zielonych testów lub prognoz.\n')
 add('## Główny wynik i pary A/B\n')
 add(table(['Seria / wariant','Ukończone / próby','DNF','Mediana ukończeń [s]','Min–max ukończeń [s]','Rozstęp [s]','Cała zadeklarowana seria PASS'],[[x['phase']+' / '+('baza' if x['baseline'] else 'nowy'),str(x['completed'])+'/'+str(x['attempts']),x['dnf'],f(x['median_completed_s'],6),f(x['minimum_completed_s'],6)+'–'+f(x['maximum_completed_s'],6),f(x['range_completed_s'],6),'TAK' if x['all_pass'] else 'NIE'] for x in a['groups']]))
 add('\nMediana opisuje tylko ukończenia i zawsze występuje z liczbą DNF. Nie obliczamy średniego czasu z pominięciem nieukończeń ani nie przypisujemy DNF sztucznego czasu mety. Seria v5 pozostaje osobnym nieudanym eksperymentem, nawet po poprawce v6.\n')
 if base and not any(r['pass_'] for r in base):add(f"Nowy wariant ukończył {sum(r['pass_'] for r in new)}/{len(new)} porównywalnych prób, baza 0/{len(base)}. Jest to zmierzona poprawa niezawodności. **Przewaga czasu względem bazy S jest nieocenialna**: nie istnieje jej ukończony czas trzech okrążeń. Nie podajemy procentowej poprawy czasu. Historyczne wyniki L 53,989766 s i 55,167079 s nie są biegami S i nie stanowią tu punktu odniesienia.\n")
 add(table(['Warunki','Baza','Nowy','Czas bazy / nowego [s]','Różnica czasu [s]','Identyczny pełny stan startowy'],[[p['scenario'],'PASS S3' if p['base_pass'] else 'DNF','PASS S3' if p['new_pass'] else 'DNF',f(p['base_time_s'],6)+' / '+f(p['new_time_s'],6),f(p['time_gain_s'],6),'TAK' if p['identical_initial'] else 'NIE'] for p in a['pairs'] if p['phase']=='final-v6']))
 add('## Każda pełna próba końcowa\n')
 add(table(['Próba','Wynik','Okr. 1 [s]','Okr. 2 [s]','Okr. 3 [s]','Meta [s]','Droga XY [m]','Pose / swept min [m]','ABSTAIN','CPU całe [s]'],[[r['label'],status(r),*[f(t,6) for t in r['lap_times_s']],f(r['finish_s'],6),f(r['distance_m']),f(r['minimum_pose_m'])+' / '+f(r['minimum_sweep_m']),r['abstain'],f(r['charged_cpu_s'])] for r in new+base]))
 add('\nKażdy wiersz rozpoczyna się od rzeczywiście zatrzymanego stanu: prędkość 0, pusta pending, aktywny gaz i skręt 0, oryginalne koło/wał/aktuator. Na początku pierwszej zapisanej próbki świata może już być komenda wydana w chwili 0; stan **przed decyzją** znajduje się w `policies/.../decision-0000.json.gz` lub `abstain.json.gz`. To ten pełny stan porównano parami. Meta jest interpolowanym rzeczywistym przekroczeniem w natywnym kroku; ostatnia próbka może leżeć do 0,01 s za metą. Do walidacji bezpieczeństwa pozostawiono także ten cały końcowy krok.\n')
 add('## Sześć łuków i proste\n\nW każdej komórce łuku: **wejście / minimum / wyjście [km/h]**. Granice geometryczne wynikają z niezmienionego G0; minimum pochodzi z pełnych próbek, a wejście i wyjście z interpolacji natywnych przekroczeń. Brak osiągnięcia łuku pozostaje „—”.\n')
 bend_map={r['label']:[b for b in a['bends'] if b['trial']==r['label']] for r in new+base}
 add(table(['Próba']+['Łuk '+str(j) for j in range(1,7)],[[r['label']]+[' / '.join(f(b[k],2) for k in ['entry_kph','minimum_kph','exit_kph']) for b in bend_map[r['label']]] for r in new+base]))
 add('\n[Pełne sześć łuków](six-bends.csv): także czas, gaz, β, yaw, wheelspin i swept. [Profile prostych](straights.csv): maksimum i średnia czasowa dla każdej prostej w każdym okrążeniu. Prosta przecinająca linię start/meta jest podzielona na odcinek do pierwszego łuku oraz odcinek po drugim łuku; dlatego tabela ma dziewięć odcinków na trzy okrążenia. Wykres prędkości zachowuje pełny profil biegu.\n')
 add(table(['Próba','Maks. na prostych [km/h]','Gaz 0 / częściowy / 100% [%]','|β| maks. [°]','|yaw| maks. [rad/s]','|wheelspin| maks.'],[[r['label'],f(max((s['maximum_kph'] for s in a['straights'] if s['trial']==r['label'] and s['maximum_kph'] is not None),default=None),2),' / '.join(f(100*r['gas'][k],2) if r['gas'][k] is not None else '—' for k in ['zero_share','partial_share','full_share']),f(r['max_beta_deg']),f(r['max_yaw_rads']),f(r['max_wheelspin'])] for r in new+base]))
 add(table(['Próba','|Fx przód| maks. [N]','|Fy przód| maks. [N]','|Fx tył| maks. [N]','|Fy tył| maks. [N]'],[[r['label']]+[f(r['forces_peak_N'][k],2) for k in ['front_fx_body_N','front_fy_body_N','rear_fx_N','rear_fy_N']] for r in new+base]))
 add('\nPełne `intervals/*.csv.gz` w każdej fazie zawierają 100 Hz: Fx/Fy obu osi, wheelspin, β, yaw, rzeczywistą krzywiznę XY, gaz żądany i aktywny, koło/wał, obciążenia, pracę i straty energii. Czasowy udział gazu obliczono z **aktywnej** komendy, z uwzględnieniem opóźnienia i interpolowanej mety. DNF przy czasie 0 nie ma zdefiniowanego udziału gazu ani swept interwału.\n')
 add('## Kontroler i pending\n')
 add('Nowy generator nie odczytuje demonstracji ani wcześniej znalezionych przyszłych komend. Z bieżącej obserwacji fizycznie propaguje nieodwracalny prefiks 0,24 s, z całą aktywną komendą, pending i czasami aktywacji, kołem, wałem oraz skrętem. Dopiero dla tego przyszłego stanu wyznacza korektę linii, prędkości, β i yaw. Inwersja **oryginalnych** sił opon i silnika dobiera wspólnie gaz oraz kierownicę. Docelowa prędkość rozwojowa wynosi 10 m/s; to spokojna baza autonomii, a nie poszukiwanie rekordu offline. Gładkie zejście z legalnego pola startowego do offsetu 3,5 m kończy się przed pierwszym łukiem.\n')
 add('Plan powstaje przyczynowo z kolejnych własnych przewidywanych stanów. Zachowane własne plany służą jako propozycje; po rzeczywistej obserwacji są korygowane i ponownie propagowane. Zmiana dowolnej części pending uniemożliwia uznanie obserwacji za identyczną z dawnym stanem. Wyczerpaną końcówkę własnego planu odnawia ten sam sterownik stanu; nie wstawia historycznej taśmy. Po przesunięciu celu zachowana propozycja musi przejść całą nową rezerwę.\n')
 add('Każda wykonana decyzja ma świeże 13 węzłów / 9 pełnych rezerw i niezależny preflight. Zachowano skończone skorelowane innowacje z bazowego protokołu, cały fizyczny obrys ≥0,5 m, swept intervals, β ≤45°, oryginalne aktuatory, reakcję 0,24 s i przeglądy co 0,2 s. To dowód dla zadeklarowanych scenariuszy i skończonego zbioru innowacji, nie globalny dowód wszystkich stanów ani wyścigu czterech rywali. Wybrane rezerwy są odtwarzane osobnym fizycznym providerem; cache propozycji nie zastępuje certyfikacji.\n')
 add('**Korekta ustalenia z #157:** generator tamtego pliku szukał wywołania `Feedback153.Action(Runtime,state,anchor)` bez spacji, a rzeczywisty plik zawierał spacje. W efekcie wykonanie #157 nadal używało starego hooka Feedback153, mimo opisu sprzężonej korekty. W #158 dopasowanie uwzględnia białe znaki i wymusza brak starego hooka; rzeczywiście wywołuje Feedback158 i Joint158. Zamrożonych źródeł ani raportów #157 nie poprawiano wstecz.\n')
 add('## Pełne porażki i rozwój przed zamrożeniem\n')
 dev=[r for r in all_rows if not r['validation']]
 add(table(['Próba rozwojowa','Wynik','Koniec obserwacji [s]','Ukończone okrążenia','Meta [s]','Powód'],[[r['label'],status(r),f(r['observed_until_s']),r['completed_laps'],f(r['finish_s'],6),r['outcome']] for r in dev]))
 add('Pierwszy natywny v3 zatrzymał się przy 101,0 s, około 3,8 m przed końcem trzeciego okrążenia. Po dojściu prognozy do mety końcowy węzeł nadal potrzebował realnej dalszej rezerwy. Naprawa **wydłuża** końcową rezerwę o 32 m za metę; nie skraca certyfikatu i nie oznacza zawodnika jako ukończonego na podstawie prognozy. V4 jako pierwszy rzeczywiście ukończył pełne S w 101,390130575 s.\n')
 add('V5 zamrożono przed pięcioma próbami; wynik to 4/5 i jedna odmowa startu A. Wspólny generator zbyt długo utrzymywał wewnętrzną linię startową: przy ref. 81,36 m prognozowany swept spadał do około 0,4549 m. Nie wykonano niecertyfikowanej komendy. Po tej diagnozie v6 przesuwa koniec gładkiego zejścia z wyjścia pierwszego łuku na jego wejście. Do opracowania użyto tylko znanego A i nominalnego B. V6 ma sześć warunków części niezależnej (nominalny i pięć nowych odłożonych) oraz cztery dodatkowe regresje v5, łącznie dziesięć różnych warunków; wszystkie dziesięć wymagane do końcowego PASS.\n')
 add('Kolektor v5 miał błąd `Min()` na pustej liście interwałów przy ABSTAIN w chwili 0. Surowy świat, journal i odrzucona polityka były już zapisane. Analiza jawnie odtworzyła status DNF z tych logów; nie odtwarzała jazdy. Poprawka v6 zapisuje w tej sytuacji swept `null` i normalny wynik DNF. Wszystkie sześć takich przypadków v5 pozostało w tabelach i kosztach. Wczesne błędne eksperymenty inwersji oraz niezgodna o ulp wersja prefiksu również są zachowane.\n')
 add('## CPU i zgodność optymalizacji\n')
 add(table(['Próba','CPU decyzji średnia / mediana / maks. [s]','CPU callback razem [s]','CPU bieg+eksport [s]','Odrzucone / naprawione plany','Pełne K1'],[[r['label'],' / '.join(f(r['callback_cpu'][k]) for k in ['mean','median','maximum']),f(r['callback_cpu_total']),f(r['charged_cpu_s']),str(r['rejected_plans'])+' / '+str(r['repaired_plans']),r['full_k1']] for r in new+base]))
 add('\n„Naprawiony” oznacza decyzję z legalnym certyfikatem po co najmniej jednej odrzuconej próbie; to nie liczba przełączeń silnika ani kontaktów. Profile faz każdej decyzji i liczniki wszystkich prognoz pozostają w `policies/` oraz `analysis.json`. CPU callback obejmuje zapis dowodu; koszt całego procesu obejmuje też przygotowanie i eksport. Kosztów równolegle uruchomionych procesów nie interpretujemy jako porównania mikrooptymalizacji przy identycznym obciążeniu.\n')
 if new:
  costs=[r['charged_cpu_s'] for r in new];mean=statistics.mean(costs);four=4*mean
  add(f"Średni koszt nowego pełnego biegu: {mean:.3f} CPU-s. Proste przemnożenie przez czterech zawodników daje {four:.3f} CPU-s ({four/60:.2f} minut CPU), **bez** dodatkowych interakcji i wspólnego planowania. To estymacja obciążenia, nie test wyścigu czterech zawodników. Przegląd 0,2 s nie jest limitem CPU 0,2 s; wyścig może być obliczany przed animacją. Koszt nadal wymaga dalszej redukcji i osobnego pomiaru dla czterech rywali.\n")
 add('Optymalizacje zachowują pełny klucz fizyczny z pending: 0,2 s nieodwracalnego prefiksu pochodzi z już policzonych 0,24 s, a odpowiedzi oryginalnej inwersji Joint150 są pamiętane według pełnych bitów stanu i gazu/skrętu. Odrzucona wersja `exactInitialWheel:true` różniła się o ulp w 4/72 stanach; wersja kanoniczna daje 72/72 identycznych bitowo przejść. Test celowo uszkodzonego cache wymaga od niezależnego providera wykrycia różnicy. `nominal-memo-proof.json` potwierdza identyczność wszystkich 10 153 natywnych próbek i wszystkich komend między v4 a v5 nominalnym.\n')
 ledgers=list(D.rglob('budget.json'));entries=[row for p in ledgers for row in read(p)];exports=[read(p) for p in (D/'analysis-costs').glob('*.json')];total=sum(r['CpuSeconds'] for r in entries+exports);worlds=sum(r['NativeWorlds'] for r in entries)
 add(f"Dotychczasowy jawny rachunek: {total:.6f} CPU-s, {worlds} nowych natywnych światów (wszystkie, także DNF i rozwój). Osobne koszty analizy/eksportu są w `analysis-costs/`. Końcowy spis zawiera także koszt tego eksportu. Nie przeniesiono limitu 1000 CPU-s / 15 światów z #157; nie jest to budżet zadania #158. Ustalony przed v6 operacyjny limit jednej próby wynosi 2400 CPU-s, jednej decyzji 60 CPU-s; przekroczenie oznacza DNF. Kompilacje i standardowe regresje nie są rolloutami badawczymi.\n")
 add('## Artefakty i walidacja\n\n- [Replay porównawczy](Replay-158.html): wyłącznie zapisane natywne stany, wszystkie serie i DNF.\n- [Wszystkie próby](trials.csv), [sześć łuków](six-bends.csv), [proste](straights.csv), [pełna analiza](analysis.json).\n- [Linie i profile prędkości](plots/lines-speed.png), [fizyka nominalnego biegu](plots/physics.png).\n- `native/`, `journals/`, `policies/`, `sources/` w każdej fazie: pełne logi światów, decyzji, dowody i źródła użyte w danej próbie.\n- `controller-freeze.json`, `scenarios-frozen.json`, [niezmienione źródła fizyki i historii](source-proof.json).\n- [Walidacja C#, Python, Node i Windows CI](VALIDATION.md).\n')
 (D/'REPORT.md').write_text('\n'.join(parts),encoding='utf-8')
 replay=read(D/'replay.json');geometry=read(R/'tools/replay-viewer/geometry.json');sections=[s for segment in geometry['segments'] for s in segment['sections'][::5]];boundaries=[[dict(x=s[k]['x'],y=s[k]['y']) for s in sections] for k in ['inner','outer']]
 replay.update(verdict=verdict,lap_m=geometry['lapMeters'],boundaries=boundaries)
 for run in replay['runs']:run['display_phase']=run['phase'] if run['validation'] else run['phase']+' · rozwój'
 write(D/'replay.json',replay)
 template=(R/'tools/robust-three-lap/replay158.html').read_text(encoding='utf-8');model=(R/'tools/replay-viewer/study158-model.mjs').read_text(encoding='utf-8').replace('export ','');(D/'Replay-158.html').write_text(template.replace('/*MODEL*/',model).replace('/*DATA*/',json.dumps(replay,ensure_ascii=False,separators=(',',':'))),encoding='utf-8')
 plots(replay,new)
 write(D/'analysis-costs'/f'{tag}.json',dict(Name=tag,CpuSeconds=time.process_time()-entered+1,NativeWorlds=0,Complete=True))
 print(verdict)

def plots(data,new):
 import matplotlib
 matplotlib.use('Agg')
 import matplotlib.pyplot as plt
 (D/'plots').mkdir(exist_ok=True);fig,ax=plt.subplots(1,2,figsize=(14,5.5));runs=[r for r in data['runs'] if r['phase']=='final-v6' and r['validation'] and not r['baseline']]
 for r in runs:
  ss=r['samples'];label=r['scenario']['Id'];ax[0].plot([s['x'] for s in ss],[s['y'] for s in ss],lw=1,label=label);ax[1].plot([s['t'] for s in ss],[s['speed'] for s in ss],lw=.8,label=label)
 for b in data['boundaries']:ax[0].plot([p['x'] for p in b],[p['y'] for p in b],color='gray',lw=.7)
 ax[0].set(xlabel='x [m]',ylabel='y [m]',aspect='equal',title='Actual three-lap paths');ax[1].set(xlabel='time [s]',ylabel='speed [km/h]',title='Every final new-controller attempt')
 for a in ax:a.grid(alpha=.2)
 ax[1].legend(fontsize=7,ncol=2);fig.tight_layout();fig.savefig(D/'plots/lines-speed.png',dpi=150);plt.close(fig)
 if not runs:return
 r=next((r for r in runs if r['scenario']['Id']=='nominal-B'),runs[0]);folder=D/'final-v6/intervals';p=folder/(r['name']+'.csv.gz')
 if not p.exists():return
 rows=list(csv.DictReader(gzip.open(p,'rt',encoding='utf-8')));t=[float(q['time_s']) for q in rows];fig,axs=plt.subplots(4,1,figsize=(12,10),sharex=True)
 for key in ['front_fx_body_N','front_fy_body_N','rear_fx_N','rear_fy_N']:axs[0].plot(t,[float(q[key]) for q in rows],label=key,lw=.8)
 for key in ['beta_deg','steering_deg']:axs[1].plot(t,[float(q[key]) for q in rows],label=key,lw=.8)
 for key in ['yaw_rads','wheel_slip','active_gas']:axs[2].plot(t,[float(q[key]) for q in rows],label=key,lw=.8)
 for key in ['inner_m','outer_m','sweep_m']:axs[3].plot(t,[float(q[key]) for q in rows],label=key,lw=.8)
 axs[3].axhline(.5,color='red',ls='--',label='S 0.5 m');axs[3].set_xlabel('native time [s]');axs[0].set_ylabel('force [N]');axs[1].set_ylabel('angle [deg]');axs[2].set_ylabel('rad/s / ratio');axs[3].set_ylabel('clearance [m]')
 for a in axs:a.legend(fontsize=7,ncol=4);a.grid(alpha=.2)
 fig.suptitle('Study158 nominal — full original native forces and swept intervals');fig.tight_layout();fig.savefig(D/'plots/physics.png',dpi=150);plt.close(fig)

if __name__=='__main__':render(sys.argv[1] if len(sys.argv)>1 else 'report-v1')
